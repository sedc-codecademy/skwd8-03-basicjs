let hotel = {
    name: "Palas",
    rooms: 40,
    booked: 25,
    gym: true,
    spa: false,
    roomTypes: ['Single', 'Twin', 'Double'],
    checkAvailability()
    {
        return this.rooms - this.booked;
    }
}; //Literal definition of object
console.log(hotel);
// let name = 'Palas';
// let rooms = 40;
// let booked = 25;

// function processHotel(name, rooms, booked)
// {

// }

// processHotel(name, rooms, booked)

processHotel(hotel)
{
    /*
        hotel.name
        hotel.rooms
    */
}

var addressbook = {
    name: 'Igor',
    lastname: 'Lastname',
    phone: '+389',
    history: [],
    getCurrentContact: function()
    {
        return `${this.name} ${this.lastname} has following phone ${this.processHotelphone}`
    },
    updateAddressBook: function(name, lastname, phone)
    {
        let person = {name: this.name, lastname: this.lastname, phone: this.phone};
        this.history.push(person);

        this.name = name;
        this.lastname = lastname;
        this.phone = phone;
        this.getCurrentContact();
    },
    getAllContacts: function(){
        this.history.map((person) => {
            console.log(person.name, person.lastname, person.phone);
        })
    }
};
//Add name, lastname, phone properties with values
//Add function that will return current values of name, lastname, phone


function Hotel(name, rooms, booked)
{
    this.name = name;
    this.rooms = rooms;
    this.booked = booked;
    this.checkAvailability = function()
    {
        return this.rooms - this.booked;
    }
}
let hotel1 = new Hotel('Palas', 50, 15);
let hotel2 = new Hotel('Inex', 100, 10);

let hotels = [hote1, hotel2]; 

let hotelsObject = {
    hotel1: new Hotel('Drim', 40, 10),
    hotel2: new Hotel('Ambasador', 50, 5)
}

function topHotel()
{
    let name = 'This is a top hotel';
    let rooms = 1000;
    let spa = true;
    let booked = 999;

    return [name, rooms, spa, booked];
}

let topHotel1 = topHotel();

//Exercise 1
var student = {
    name: 'Student some',
    class: 'IV',
    rollno: 4
}

for(let x in student)
{
    console.log(x, student[x]);
}

//Exercise 2
console.log(`Value of rollno is: ${student.rollno}`);
delete student.rollno;

//Exercise 3
function checkProperty(propertyName)
{
    if(student[propertyName]) //student.hasOwnProperty(propertyName)
        console.log(`Have property: ${propertyName}`) 
    else
        console.log(`Doesn't have property: ${propertyName}`) 
}

checkProperty('name');
checkProperty('primer');

//Exercise4
 function Car(model, color, year, fuel, fuelConsumption)
 {
     this.model = model;
     this.color = color;
     this.year = year;
     this.fuel = fuel;
     this.fuelConsumption = fuelConsumption;
     this.calculateConsumption = function(km)
     {
         let consumption = (km / 100) * this.fuelConsumption;
         return consumption;
     }
 };

 let car2 = {
     model: 'Toyota',
     color: 'Green',
     year: 2018,
     fuel: 'Hybrid',
     fuelConsumption: 3,
     calculateConsumption: function(km)
     {
         let consumption = (km / 100) * this.fuelConsumption;
         return consumption;
     }
 }

 let car1 = new Car('Mazda', 'Yellow', 2015, 'Diesel', 5);
 console.log(`car ${car1.model} spends ${car1.calculateConsumption(300)} L per 300 km`);